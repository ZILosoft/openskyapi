cities = {
    'Tyumen': {'latitude': 58.20, 'longitude': 68.25},
    'Berlin': {'latitude': 52.520008, 'longitude': 13.404954}
}
